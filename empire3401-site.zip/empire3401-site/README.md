# Empire of 3401 — GitHub Pages Website

Kingdom 3401向けの壮大な帝国風Webサイトテンプレートです。  
Rise of Kingdoms公式素材は使わず、著作権リスクを避けるためにオリジナルSVG画像を同梱しています。

## ファイル構成

```text
index.html
styles.css
script.js
assets/
  crest.svg
  hero-castle.svg
  imperial-throne.svg
  war-banners.svg
  empire-map.svg
  og-image.svg
  noise.svg
.github/workflows/pages.yml
```

## GitHub Pagesで公開する方法

1. GitHubで新しいリポジトリを作成
2. このフォルダ内のファイルをすべてアップロード
3. `Settings` → `Pages` → `Build and deployment`
4. Sourceを `GitHub Actions` に設定
5. `Actions` が完了すると公開URLが発行されます

## 編集すべき箇所

- `index.html`
  - 同盟名
  - ルール
  - Council / R4 / R5
  - Discordリンク
  - 移民条件
  - KvK戦績

- `assets/*.svg`
  - ロゴや画像を差し替え可能

## 注意

このサイトはファンメイド用テンプレートです。  
Rise of KingdomsおよびLilith Gamesとは関係ありません。
公式画像・ゲーム内スクリーンショットを使う場合は、利用規約や著作権に注意してください。
