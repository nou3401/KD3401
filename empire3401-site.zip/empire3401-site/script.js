const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.nav');
const glow = document.querySelector('.cursor-glow');
const embers = document.querySelector('.embers');

navToggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
});

document.querySelectorAll('.nav a').forEach(link => {
  link.addEventListener('click', () => nav.classList.remove('open'));
});

window.addEventListener('mousemove', (event) => {
  if (!glow) return;
  glow.style.left = `${event.clientX}px`;
  glow.style.top = `${event.clientY}px`;
});

for (let i = 0; i < 72; i++) {
  const s = document.createElement('span');
  s.style.left = `${Math.random() * 100}%`;
  s.style.animationDuration = `${5 + Math.random() * 9}s`;
  s.style.animationDelay = `${Math.random() * 9}s`;
  s.style.width = s.style.height = `${2 + Math.random() * 4}px`;
  embers.appendChild(s);
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.18 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
